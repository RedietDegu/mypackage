# mypackage
this library is created as an example of how to publish our own package 
# how to insat
...