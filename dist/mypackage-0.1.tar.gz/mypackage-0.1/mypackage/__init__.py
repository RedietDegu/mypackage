from . import myModule

